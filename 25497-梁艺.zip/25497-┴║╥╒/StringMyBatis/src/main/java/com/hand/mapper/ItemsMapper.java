package com.hand.mapper;

import com.hand.entity.UserOrderItemDetail;

import java.util.List;

public interface ItemsMapper {
    public List<UserOrderItemDetail> selectAllMeaage();
}
