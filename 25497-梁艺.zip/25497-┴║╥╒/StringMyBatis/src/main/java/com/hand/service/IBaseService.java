package com.hand.service;

public interface IBaseService {
}
